<?php
require 'db.php';
session_start();
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $id;
            $_SESSION["username"] = $username;
            header("Location: welcome.php");
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Username not found.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body style="font-family: times new roman; background-color: green;color:blue">
<div style="width: 350px; padding: 40px; margin: 100px auto; background: yellow; border-radius: 8px;">
    <h2 style="text-align: center;">Login</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required 
            style="font-family: times new roman; width: 100%; padding: 10px; margin: 8px 0; border-radius: 4px;"><br>
        <input type="password" name="password" placeholder="Password" required 
            style="font-family: times new roman; width: 100%; padding: 10px; margin: 8px 0;border-radius: 4px;"><br>
        <button type="submit" 
            style="font-family: times new roman;width: 100%; padding: 10px;margin: 8px 0;  background-color: pink; color: red;  border-radius: 10px;">Login</button>
        <p style="color: red; font-size: 0.9em;"><?php echo $error; ?></p>
    </form>
    <p style="text-align: center;">New user? <a href="signup.php"><b>Sign up</b></a></p>
</div>
</body>
</html>
