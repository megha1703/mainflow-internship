<?php
session_start();
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body style="font-family: times new roman; background-color: green;">
<div style="width: 300px; padding: 20px; margin: 100px auto; background: yellow; box-shadow: 0 0 10px #ccc; border-radius: 8px; text-align: center;">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h2>
    <a href="logout.php" 
       style="display: inline-block; margin-top: 15px; padding: 10px 15px; background-color: red; color: blue; border: none; border-radius: 4px; text-decoration: none;">
        Logout
    </a>
</div>
</body>
</html>
