<?php
require 'db.php';
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $check->bind_param("s", $username);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $error = "Username already taken!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hashed_password);
        if ($stmt->execute()) {
            header("Location: login.php");
        } else {
            $error = "Something went wrong.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
</head>
<body style="font-family: times new roman; background-color: green;">
<div style="width: 350px; padding: 40px; margin: 100px auto; background:yellow; box-shadow: 0 0 10px #ccc; border-radius: 8px;">
    <h2 style="text-align: center;">Sign Up</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required 
            style="font-family: times new roman; width: 100%; padding: 10px; margin: 8px 0; border-radius: 4px;"><br>
        <input type="password" name="password" placeholder="Password" required 
            style="font-family: times new roman; width: 100%; padding: 10px; margin: 8px 0;  border-radius: 4px;"><br>
        <button type="submit" 
            style="font-family: times new roman; width: 100%; padding: 10px;background-color: pink; color: red;  border: none; border-radius: 4px;"><b>Register</b></button>
        <p style="color: red; font-size: 0.9em;"><?php echo $error; ?></p>
    </form>
    <p style="text-align: center;">Already registered? <a href="index.php"><b>Login</b></a></p>
</div>
</body>
</html>
